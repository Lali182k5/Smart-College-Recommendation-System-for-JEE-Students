package com.jee.jee_college_predictor.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class College {
    private String instituteName;
    private String branch;
    private String institutionType;
    private int openingRank;
    private int closingRank;
    private int year;
    private int round;
    private String state;
    private String region;

    // New fields for frontend
    private double matchPercentage;
    private int appliedCutoff;
    private String eligibilityStatus;
    private String admissionChance;
    private String id; // optional unique id (e.g., slug)

}
