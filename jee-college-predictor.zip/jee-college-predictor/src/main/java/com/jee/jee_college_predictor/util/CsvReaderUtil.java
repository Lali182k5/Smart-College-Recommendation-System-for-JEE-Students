package com.jee.jee_college_predictor.util;

import com.jee.jee_college_predictor.model.CutoffData;
import com.opencsv.bean.CsvToBeanBuilder;
import jakarta.annotation.PostConstruct;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.stereotype.Component;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * FIXED VERSION - Loads your aligned CSV files
 * Expected files in src/main/resources/data/:
 * - 2022_with_state_region_aligned.csv
 * - 2023_with_state_region_aligned.csv
 * - 2024_with_state_region_aligned.csv
 */
@Component
public class CsvReaderUtil {

    private List<CutoffData> cutoffDataList = Collections.emptyList();
    private static final String CSV_FILE_PATTERN = "classpath:data/*_with_state_region_aligned.csv";

    @PostConstruct
    public void init() {
        List<CutoffData> allData = new ArrayList<>();
        PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();

        try {
            Resource[] resources = resolver.getResources(CSV_FILE_PATTERN);
            System.out.println("Found " + resources.length + " CSV files matching pattern: " + CSV_FILE_PATTERN);

            for (Resource resource : resources) {
                String filename = resource.getFilename();
                System.out.println("Loading CSV: " + filename);

                try (InputStream inputStream = resource.getInputStream();
                     Reader reader = new InputStreamReader(inputStream)) {

                    List<CutoffData> fileData = new CsvToBeanBuilder<CutoffData>(reader)
                            .withType(CutoffData.class)
                            .withIgnoreLeadingWhiteSpace(true)
                            .build()
                            .parse();

                    System.out.println("  Loaded " + fileData.size() + " entries from " + filename);
                    allData.addAll(fileData);

                } catch (Exception e) {
                    System.err.println("ERROR loading " + filename + ": " + e.getMessage());
                    e.printStackTrace();
                }
            }

            cutoffDataList = allData;
            System.out.println("✅ SUCCESS: Loaded total of " + cutoffDataList.size() + " cutoff entries from " + resources.length + " files");

            // Print sample data for verification
            if (!cutoffDataList.isEmpty()) {
                CutoffData sample = cutoffDataList.get(0);
                System.out.println("Sample entry - Institute: " + sample.getInstitute() +
                        ", Program: " + sample.getAcademicProgram() +
                        ", Year: " + sample.getYear() +
                        ", Round: " + sample.getRound());
            }

        } catch (Exception e) {
            System.err.println("❌ FATAL: Error loading CSV files - " + e.getMessage());
            e.printStackTrace();
        }
    }

    public List<CutoffData> getCutoffData() {
        return new ArrayList<>(cutoffDataList);
    }
}