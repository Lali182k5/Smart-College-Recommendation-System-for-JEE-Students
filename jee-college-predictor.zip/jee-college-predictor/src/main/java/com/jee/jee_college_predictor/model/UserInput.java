package com.jee.jee_college_predictor.model;

import lombok.Data;

@Data
public class UserInput {
    private int jeeRank;
    private String category;
    private String gender;
    private String institutionTypeFilter;
    private Integer yearFilter;
    private Integer roundFilter;
    private String stateFilter;
    private String regionFilter;
}