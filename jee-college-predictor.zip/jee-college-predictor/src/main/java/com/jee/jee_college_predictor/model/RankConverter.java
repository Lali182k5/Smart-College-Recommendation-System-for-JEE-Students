package com.jee.jee_college_predictor.model; // Or a new "converter" package

import com.opencsv.bean.AbstractBeanField; // This is the correct class to import
import com.opencsv.exceptions.CsvConstraintViolationException;
import com.opencsv.exceptions.CsvDataTypeMismatchException;

public class RankConverter extends AbstractBeanField<Integer, String> {

    @Override
    protected Integer convert(String value) throws CsvDataTypeMismatchException, CsvConstraintViolationException {
        if (value == null || value.trim().isEmpty()) {
            return 0;
        }
        // Remove the 'P' and any whitespace, then parse to an Integer
        String cleanedValue = value.trim().toUpperCase().replace("P", "");
        try {
            return Integer.parseInt(cleanedValue);
        } catch (NumberFormatException e) {
            throw new CsvDataTypeMismatchException("Failed to convert '" + value + "' to an Integer.");
        }
    }
}