package com.jee.jee_college_predictor.service;

import com.jee.jee_college_predictor.model.College;
import com.jee.jee_college_predictor.model.CutoffData;
import com.jee.jee_college_predictor.model.UserInput;
import com.jee.jee_college_predictor.util.CsvReaderUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

/**
 * FIXED VERSION with enhanced debugging and gender mapping
 */
@Service
public class PredictionService {

    @Autowired
    private CsvReaderUtil csvReaderUtil;

    public List<College> getPredictedColleges(UserInput userInput) {
        List<CutoffData> allCutoffData = csvReaderUtil.getCutoffData();

        System.out.println("=== PREDICTION REQUEST ===");
        System.out.println("Total cutoff data available: " + allCutoffData.size());
        System.out.println("User Input: " + userInput);

        final int userRank = userInput.getJeeRank();
        final String userCategory = StringUtils.hasText(userInput.getCategory()) ?
                userInput.getCategory().trim().toUpperCase(Locale.ROOT) : "OPEN";
        final String userGender = normalizeGender(userInput.getGender());
        final String stateFilter = userInput.getStateFilter() != null ? userInput.getStateFilter().trim() : "";
        final String regionFilter = userInput.getRegionFilter() != null ? userInput.getRegionFilter().trim() : "";
        final String typeFilter = userInput.getInstitutionTypeFilter() != null ?
                userInput.getInstitutionTypeFilter().trim() : "";

        System.out.println("Normalized - Category: " + userCategory + ", Gender: " + userGender +
                ", Type: " + typeFilter + ", State: " + stateFilter + ", Region: " + regionFilter);

        List<College> results = allCutoffData.stream()
                // basic eligibility by closing rank (skip rows with closingRank == 0)
                .filter(data -> {
                    boolean valid = data.getClosingRank() > 0;
                    return valid;
                })
                .filter(data -> userRank <= data.getClosingRank() * 5) // broaden initial set
                .filter(data -> !StringUtils.hasText(stateFilter) ||
                        data.getState().equalsIgnoreCase(stateFilter))
                .filter(data -> !StringUtils.hasText(regionFilter) ||
                        data.getRegion().equalsIgnoreCase(regionFilter))
                .filter(data -> userInput.getYearFilter() == null ||
                        data.getYear() == userInput.getYearFilter())
                .filter(data -> userInput.getRoundFilter() == null ||
                        data.getRound() == userInput.getRoundFilter())
                .filter(data -> {
                    // seatType vs userCategory match (tolerant)
                    String seat = data.getSeatType() == null ? "" : data.getSeatType().trim().toUpperCase();
                    boolean match = seat.isEmpty() || seat.equals(userCategory) ||
                            userCategory.equals("OPEN") || seat.contains(userCategory);
                    return match;
                })
                .filter(data -> {
                    // Gender compatibility: Gender-Neutral matches all, otherwise exact match
                    String rowGender = data.getGender() == null ? "" : data.getGender().trim();
                    boolean match = rowGender.equalsIgnoreCase("Gender-Neutral") ||
                            rowGender.equalsIgnoreCase(userGender) ||
                            (rowGender.contains("Female") && userGender.equalsIgnoreCase("Female")) ||
                            userGender.isEmpty();
                    return match;
                })
                .filter(data -> {
                    // Institution type filter
                    if (!StringUtils.hasText(typeFilter)) return true;
                    String instType = mapInstituteToType(data.getInstitute());
                    return instType.equalsIgnoreCase(typeFilter);
                })
                .map(data -> {
                    int cutoff = data.getClosingRank();

                    // Compute match percentage
                    double match;
                    if (userRank <= 0) {
                        match = 15.0;
                    } else if (userRank <= cutoff * 0.8) {
                        match = 92 + Math.random() * 7;
                    } else if (userRank <= cutoff) {
                        match = 75 + Math.random() * 12;
                    } else if (userRank <= cutoff * 1.2) {
                        match = 55 + Math.random() * 12;
                    } else if (userRank <= cutoff * 1.5) {
                        match = 35 + Math.random() * 15;
                    } else {
                        match = 10 + Math.random() * 25;
                    }

                    // Boost for filter matches
                    if (StringUtils.hasText(regionFilter) && data.getRegion() != null &&
                            data.getRegion().equalsIgnoreCase(regionFilter)) match += 4;
                    if (StringUtils.hasText(stateFilter) && data.getState() != null &&
                            data.getState().equalsIgnoreCase(stateFilter)) match += 3;
                    if (StringUtils.hasText(typeFilter) &&
                            mapInstituteToType(data.getInstitute()).equalsIgnoreCase(typeFilter)) match += 4;

                    match = Math.max(0, Math.min(100, Math.round(match)));

                    String eligibility = userRank > 0 && userRank <= cutoff ? "Eligible" : "Not Eligible";
                    String chance = match > 75 ? "High" : match > 45 ? "Medium" : "Low";

                    College c = new College();
                    c.setInstituteName(data.getInstitute());
                    c.setBranch(data.getAcademicProgram());
                    c.setInstitutionType(mapInstituteToType(data.getInstitute()));
                    c.setOpeningRank(data.getOpeningRank());
                    c.setClosingRank(data.getClosingRank());
                    c.setYear(data.getYear());
                    c.setRound(data.getRound());
                    c.setState(data.getState());
                    c.setRegion(data.getRegion());
                    c.setAppliedCutoff(cutoff);
                    c.setMatchPercentage(match);
                    c.setEligibilityStatus(eligibility);
                    c.setAdmissionChance(chance);

                    String slug = (data.getInstitute() + "-" + data.getAcademicProgram())
                            .toLowerCase().replaceAll("[^a-z0-9]+", "-");
                    c.setId(slug);

                    return c;
                })
                .sorted((a, b) -> Double.compare(b.getMatchPercentage(), a.getMatchPercentage()))
                .limit(100) // Limit to top 100 results
                .collect(Collectors.toList());

        System.out.println("✅ Returning " + results.size() + " predictions");
        if (results.isEmpty()) {
            System.out.println("⚠️ WARNING: No results found. Check filters and rank.");
        } else {
            System.out.println("Top result: " + results.get(0).getInstituteName() +
                    " - " + results.get(0).getBranch() +
                    " (Match: " + results.get(0).getMatchPercentage() + "%)");
        }

        return results;
    }

    /**
     * Normalize gender values from frontend to match CSV values
     */
    private String normalizeGender(String gender) {
        if (gender == null || gender.isEmpty()) return "Gender-Neutral";

        String lower = gender.toLowerCase().trim();
        if (lower.contains("neutral") || lower.equals("all")) {
            return "Gender-Neutral";
        } else if (lower.contains("female") || lower.equals("f")) {
            return "Female";
        } else if (lower.contains("male") || lower.equals("m")) {
            return "Male";
        }
        return gender; // Return as-is if no match
    }

    private String mapInstituteToType(String instituteName) {
        if (instituteName == null) return "Other";
        String lower = instituteName.toLowerCase();
        if (lower.contains("indian institute of technology")) return "IIT";
        if (lower.contains("national institute of technology")) return "NIT";
        if (lower.contains("indian institute of information technology")) return "IIIT";
        if (lower.contains("gift")) return "GIFT";
        return "Other";
    }
}