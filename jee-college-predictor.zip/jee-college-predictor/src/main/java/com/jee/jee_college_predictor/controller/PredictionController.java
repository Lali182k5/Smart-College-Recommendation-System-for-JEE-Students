
package com.jee.jee_college_predictor.controller;

import com.jee.jee_college_predictor.model.College;
import com.jee.jee_college_predictor.model.UserInput;
import com.jee.jee_college_predictor.service.PredictionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/predict")
@CrossOrigin(origins = {"http://localhost:3000", "http://localhost:5173"})
public class PredictionController {

    @Autowired
    private PredictionService predictionService;

    @PostMapping
    public ResponseEntity<List<College>> predictColleges(@RequestBody UserInput userInput) {
        if (userInput.getJeeRank() <= 0 || userInput.getCategory() == null || userInput.getGender() == null) {
            return ResponseEntity.badRequest().build();
        }

        List<College> predictedColleges = predictionService.getPredictedColleges(userInput);
        return ResponseEntity.ok(predictedColleges);
    }
}