package com.jee.jee_college_predictor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JeeCollegePredictorApplication {

	public static void main(String[] args) {
		SpringApplication.run(JeeCollegePredictorApplication.class, args);
	}

}
