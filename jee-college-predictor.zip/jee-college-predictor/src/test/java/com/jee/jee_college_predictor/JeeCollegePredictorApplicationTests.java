package com.jee.jee_college_predictor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JeeCollegePredictorApplicationTests {

	@Test
	void contextLoads() {
	}

}
